﻿using DataTransferPart2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataTransferPart2.ViewModels
{
    public class HomeVM
    {
        public List<Student> Students { get; set; }
        public int [] arr { get; set; }

    }
}
